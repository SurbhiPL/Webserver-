# DevOps_project 1
DevOps project to learn how to setup webserver and host website on ec2 

This repository contains the code for my DevOps project, which is a simple website built using HTML and deployed on an EC2 instance with Apache web server.

Table of Contents
Installation
Usage
Contributing
License
Installation
To run this website locally, you can simply clone this repository to your local machine:

bash
Copy code
git clone https://github.com/your-username/devops-project.git
Usage
Once you have cloned the repository, you can open the index.html file in your web browser to view the website.

The website displays a message that the web server has been successfully deployed on an EC2 instance, and provides a button to share the website on LinkedIn.

Contributing
If you find any issues with the website or have suggestions for improvements, feel free to submit an issue or pull request.

License
This project is licensed under the MIT License - see the LICENSE file for details.
